"""JosefGPT Local package."""
